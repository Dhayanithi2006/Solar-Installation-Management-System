# Configuration Directory

This directory stores configuration templates and runtime definitions for the Odoo environment:

- `odoo.conf`: Odoo server configuration file defining `addons_path`, database credentials, and server ports.
- `docker-compose.yml`: (When applicable) Multi-container orchestration for Odoo 18.0 and PostgreSQL.

